//  boost/filesystem/exception.hpp  -------------------------------------------//

//  Copyright Beman Dawes 2003
//  Use, modification, and distribution is subject to the Boost Software
//  License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  This header is no long used. The contents have been moved to path.hpp.
//  It is provided so that user code #includes do not have to be changed.
