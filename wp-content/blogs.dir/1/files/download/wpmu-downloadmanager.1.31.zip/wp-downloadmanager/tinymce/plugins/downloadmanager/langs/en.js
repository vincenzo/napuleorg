tinyMCE.addI18n("en.downloadmanager", {
	insert_download : 'Insert File Download'
});