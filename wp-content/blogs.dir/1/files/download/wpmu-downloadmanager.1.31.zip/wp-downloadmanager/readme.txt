=== WP-DownloadManager ===
Contributors: GamerZ
Donate link: http://lesterchan.net/wordpress
Tags: file, files, download, downloads, manager, downloadmanager, downloadsmanager, filemanager, filesmanager
Requires at least: 2.5.0
Stable tag: 1.31

Adds a simple download manager to your WordPress blog.

== Description ==

All the information (general, changelog, installation, upgrade, usage) you need about this plugin can be found here: [WP-DownloadManager Readme](http://lesterchan.net/wordpress/readme/wp-downloadmanager.html "WP-DownloadManager Readme").
It is the exact same readme.html is included in the zip package.

== Development Blog ==

[GaMerZ WordPress Plugins Development Blog](http://lesterchan.net/wordpress/ "GaMerZ WordPress Plugins Development Blog")

== Installation ==

[WP-DownloadManager Readme](http://lesterchan.net/wordpress/readme/wp-downloadmanager.html "WP-DownloadManager Readme") (Installation Tab)

== Screenshots ==

[WP-DownloadManager Screenshots](http://lesterchan.net/wordpress/screenshots/browse/wp-downloadmanager/ "WP-DownloadManager Screenshots")

== Frequently Asked Questions ==

[WP-DownloadManager Support Forums](http://forums.lesterchan.net/index.php?board=12.0 "WP-DownloadManager Support Forums")